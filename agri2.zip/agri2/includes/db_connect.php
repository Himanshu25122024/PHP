<?php
// Database configuration
$db_host = "localhost:3307";
$db_user = "root";
$db_pass = "";
$db_name = "agrismart";

// Create database connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>