<footer class="site-footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="assets/images/logo.png" alt="AgriSmart Planner Logo">
                <h3>AgriSmart Planner</h3>
                <p>Plan. Optimize. Profit from Your Agri-Waste.</p>
            </div>
            <div class="footer-links">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="learn.php">Learn</a></li>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="footer-links">
                <h4>Resources</h4>
                <ul>
                    <li><a href="learn.php#in-situ">In-situ Management</a></li>
                    <li><a href="learn.php#ex-situ">Ex-situ Management</a></li>
                    <li><a href="learn.php#solar">Solar Technologies</a></li>
                    <li><a href="learn.php#products">Waste Products</a></li>
                </ul>
            </div>
            <div class="footer-newsletter">
                <h4>Stay Updated</h4>
                <p>Subscribe to our newsletter for the latest updates on agricultural waste management.</p>
                <form action="subscribe.php" method="post">
                    <input type="email" name="email" placeholder="Your email address" required>
                    <button type="submit" class="btn btn-primary">Subscribe</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> AgriSmart Planner. All rights reserved.</p>
        </div>
    </div>
</footer>